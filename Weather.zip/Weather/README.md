Development of Weahter API Using Python


1. Install Python and Flask
	python --version
	pip --version
	pip install flask
	
2. Unzip the source code and put it in any folder.
3. Open the terminal or console and then type python rest-server.api

	The app should be up and running

	Access the API with http://localhost:5000/weather/api/v1.0

4. You can find the complete specification of the API at the WSpecification.html file

